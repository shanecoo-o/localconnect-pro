import { Appointment, AppointmentStatus, BarberId, ServiceId, VALID_TRANSITIONS } from './types';

const STORAGE_KEY = 'takehiro_appointments';

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

export function getAppointments(): Appointment[] {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveAppointments(appointments: Appointment[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appointments));
}

export function getAppointmentsByDate(date: string): Appointment[] {
  return getAppointments().filter(a => a.date === date && a.status !== 'cancelled');
}

export function getAppointmentsByBarberAndDate(barberId: BarberId, date: string): Appointment[] {
  return getAppointmentsByDate(date).filter(a => a.barberId === barberId);
}

/**
 * Check if a new appointment would overlap with existing ones.
 * A barber is "occupied" for the full duration of each booked service.
 */
export function hasOverlap(
  barberId: BarberId,
  date: string,
  time: string,
  durationMin: number,
  services: { id: ServiceId; duration: number }[]
): boolean {
  const existing = getAppointmentsByBarberAndDate(barberId, date);
  const newStart = timeToMinutes(time);
  const newEnd = newStart + durationMin;

  for (const apt of existing) {
    const svc = services.find(s => s.id === apt.serviceId);
    const aptStart = timeToMinutes(apt.time);
    const aptEnd = aptStart + (svc?.duration ?? 30);
    // Overlap if ranges intersect
    if (newStart < aptEnd && newEnd > aptStart) {
      return true;
    }
  }
  return false;
}

function timeToMinutes(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

export function createAppointment(
  serviceId: ServiceId,
  barberId: BarberId,
  date: string,
  time: string,
  clientName: string,
  services: { id: ServiceId; duration: number }[] = []
): Appointment {
  const appointments = getAppointments();

  // Find duration from services array
  const svc = services.find(s => s.id === serviceId);
  const duration = svc?.duration ?? 30;

  // Check for overlap using duration-aware logic
  if (hasOverlap(barberId, date, time, duration, services)) {
    throw new Error('Horário já reservado ou sobreposto');
  }

  const appointment: Appointment = {
    id: generateId(),
    serviceId,
    barberId,
    date,
    time,
    clientName,
    status: 'confirmed',
    createdAt: new Date().toISOString(),
  };

  appointments.push(appointment);
  saveAppointments(appointments);
  return appointment;
}

export function updateAppointmentStatus(id: string, newStatus: AppointmentStatus): Appointment {
  const appointments = getAppointments();
  const idx = appointments.findIndex(a => a.id === id);
  if (idx === -1) throw new Error('Marcação não encontrada');

  const current = appointments[idx];
  const allowed = VALID_TRANSITIONS[current.status];
  if (!allowed.includes(newStatus)) {
    throw new Error(`Transição inválida: ${current.status} → ${newStatus}`);
  }

  appointments[idx] = { ...current, status: newStatus };
  saveAppointments(appointments);
  return appointments[idx];
}
