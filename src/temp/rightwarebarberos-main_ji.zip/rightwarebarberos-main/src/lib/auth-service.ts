/**
 * Auth service layer — abstraction over localStorage for now,
 * ready to swap for a real API later.
 */

import { UserRole } from '@/stores/auth';

export interface StoredUser {
  id: string;
  name: string;
  role: UserRole;
  passwordHash: string; // plain text for now (mock), will be server-side later
}

const USERS_KEY = '503barbershop-users';

// ── Seed: Super Admin default account ──
const SEED_USERS: StoredUser[] = [
  { id: 'S001', name: 'Super Admin', role: 'super', passwordHash: 'super2025' },
];

// ── Helpers ──

function getUsers(): StoredUser[] {
  const raw = localStorage.getItem(USERS_KEY);
  const users: StoredUser[] = raw ? JSON.parse(raw) : [];
  // Ensure seed users always exist
  let changed = false;
  for (const seed of SEED_USERS) {
    if (!users.find((u) => u.id === seed.id)) {
      users.push(seed);
      changed = true;
    }
  }
  if (changed) saveUsers(users);
  return users;
}

function saveUsers(users: StoredUser[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

// ── Role resolution from ID prefix ──

export function resolveRoleFromId(id: string): UserRole {
  if (id.startsWith('A')) return 'admin';
  if (id.startsWith('B')) return 'barber';
  if (id.startsWith('C')) return 'client';
  // Super accounts are created from backend/seed only
  if (id.startsWith('S')) return 'super';
  return 'client';
}

// ── Validation helpers ──

export function validatePassword(password: string): string | null {
  if (!password) return 'Password é obrigatória';
  if (password.length < 8) return 'Password deve ter pelo menos 8 caracteres';
  return null;
}

export function validateName(name: string): string | null {
  if (!name.trim()) return 'Nome é obrigatório';
  if (name.trim().length < 2) return 'Nome deve ter pelo menos 2 caracteres';
  if (name.trim().length > 100) return 'Nome deve ter no máximo 100 caracteres';
  return null;
}

// ── Auth operations ──

export interface LoginResult {
  success: boolean;
  user?: StoredUser;
  error?: string;
}

export function loginUser(id: string, password: string): LoginResult {
  if (!id.trim()) return { success: false, error: 'ID é obrigatório' };
  const pwError = validatePassword(password);
  if (pwError) return { success: false, error: pwError };

  const users = getUsers();
  const user = users.find((u) => u.id === id.trim());

  if (!user) return { success: false, error: 'Conta não encontrada' };
  if (user.passwordHash !== password) return { success: false, error: 'Password incorrecta' };

  return { success: true, user };
}

export interface RegisterResult {
  success: boolean;
  user?: StoredUser;
  error?: string;
}

export function registerClient(name: string, password: string, generatedId: string): RegisterResult {
  const nameError = validateName(name);
  if (nameError) return { success: false, error: nameError };
  const pwError = validatePassword(password);
  if (pwError) return { success: false, error: pwError };

  const id = generatedId;

  const newUser: StoredUser = {
    id,
    name: name.trim(),
    role: 'client',
    passwordHash: password,
  };

  const users = getUsers();
  users.push(newUser);
  saveUsers(users);

  return { success: true, user: newUser };
}

/**
 * Create a user account for an existing barber/admin created from admin panel.
 * Called when admin creates barbers/admins so they can log in.
 */
export function createUserAccount(id: string, name: string, password: string, role: UserRole): RegisterResult {
  const users = getUsers();
  if (users.find((u) => u.id === id)) {
    return { success: false, error: 'Conta já existe para este ID' };
  }

  const newUser: StoredUser = { id, name, role, passwordHash: password };
  users.push(newUser);
  saveUsers(users);

  return { success: true, user: newUser };
}

export function getUserById(id: string): StoredUser | undefined {
  return getUsers().find((u) => u.id === id);
}

export function getAllUsers(): StoredUser[] {
  return getUsers();
}

export function removeUserAccount(id: string): void {
  const users = getUsers().filter((u) => u.id !== id);
  saveUsers(users);
}
