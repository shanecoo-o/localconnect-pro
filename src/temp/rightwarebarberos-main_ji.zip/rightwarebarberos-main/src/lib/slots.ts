import { BarberId, ServiceId } from './types';
import { getAppointmentsByBarberAndDate } from './appointments';

const START_HOUR = 8;
const END_HOUR = 23;

/**
 * Generate available time slots, excluding past times and occupied ranges.
 * Now takes services array directly instead of importing global SERVICES.
 */
export function generateSlots(
  barberId: BarberId,
  date: string,
  serviceId: ServiceId,
  services: { id: ServiceId; duration: number }[]
): string[] {
  const service = services.find(s => s.id === serviceId);
  if (!service) return [];

  const duration = service.duration;
  const booked = getAppointmentsByBarberAndDate(barberId, date);

  const now = new Date();
  const isToday = date === formatDate(now);

  // Build occupied ranges (start minute -> end minute)
  const occupiedRanges: { start: number; end: number }[] = booked.map(a => {
    const svc = services.find(s => s.id === a.serviceId);
    const start = timeToMin(a.time);
    return { start, end: start + (svc?.duration ?? 30) };
  });

  const slots: string[] = [];
  let minutes = START_HOUR * 60;
  const endMinutes = END_HOUR * 60;

  while (minutes + duration <= endMinutes) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    const time = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;

    const isPast =
      isToday &&
      (h < now.getHours() || (h === now.getHours() && m <= now.getMinutes()));

    // Check overlap with any occupied range
    const slotEnd = minutes + duration;
    const isOccupied = occupiedRanges.some(
      r => minutes < r.end && slotEnd > r.start
    );

    if (!isPast && !isOccupied) {
      slots.push(time);
    }

    minutes += duration;
  }

  return slots;
}

function timeToMin(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

export function formatDate(date: Date): string {
  const y = date.getFullYear();
  const m = (date.getMonth() + 1).toString().padStart(2, '0');
  const d = date.getDate().toString().padStart(2, '0');
  return `${y}-${m}-${d}`;
}
