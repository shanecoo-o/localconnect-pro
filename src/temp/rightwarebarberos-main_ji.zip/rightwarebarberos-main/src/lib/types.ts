export type ServiceId = string;
export type CategoryId = string;
export type BarberId = string;

export interface Service {
  id: ServiceId;
  name: string;
  price: number;
  duration: number;
  category: CategoryId;
  iconUrl?: string;
  bgUrl?: string;
}

export interface Category {
  id: CategoryId;
  name: string;
  description: string;
  icon: string;
  iconUrl?: string;
  bgUrl?: string;
}

export interface Barber {
  id: BarberId;
  name: string;
}

export type AppointmentStatus = 'confirmed' | 'in_service' | 'completed' | 'cancelled' | 'no_show';

export interface Appointment {
  id: string;
  serviceId: ServiceId;
  barberId: BarberId;
  date: string;
  time: string;
  clientName: string;
  status: AppointmentStatus;
  createdAt: string;
}

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'fade', name: 'Fade', description: 'Low, Mid & High', icon: '🔥' },
  { id: 'classicos', name: 'Clássicos', description: 'Buzz, Taper, Undercut, Slick', icon: '✂️' },
  { id: 'medios_longos', name: 'Médios & Longos', description: 'Man Bun, Camadas', icon: '💈' },
  { id: 'extras', name: 'Extras', description: 'Barba, Pintura', icon: '🎨' },
];

export const DEFAULT_SERVICES: Service[] = [
  { id: 'fade_low', name: 'Fade Low', price: 22, duration: 40, category: 'fade' },
  { id: 'fade_mid', name: 'Fade Mid', price: 22, duration: 40, category: 'fade' },
  { id: 'fade_high', name: 'Fade High', price: 22, duration: 40, category: 'fade' },
  { id: 'buzz_cut', name: 'Buzz Cut', price: 15, duration: 20, category: 'classicos' },
  { id: 'taper_cut', name: 'Taper Cut', price: 18, duration: 30, category: 'classicos' },
  { id: 'undercut', name: 'Undercut', price: 25, duration: 45, category: 'classicos' },
  { id: 'slick_back', name: 'Slick Back', price: 28, duration: 45, category: 'classicos' },
  { id: 'man_bun', name: 'Man Bun (Coque)', price: 35, duration: 60, category: 'medios_longos' },
  { id: 'longo_camadas', name: 'Longo em Camadas', price: 40, duration: 60, category: 'medios_longos' },
  { id: 'barba', name: 'Barba', price: 10, duration: 20, category: 'extras' },
  { id: 'pintura', name: 'Pintura', price: 15, duration: 30, category: 'extras' },
];

export const DEFAULT_BARBERS: Barber[] = [
  { id: 'rafael', name: 'Rafael' },
  { id: 'diogo', name: 'Diogo' },
];

export const VALID_TRANSITIONS: Record<AppointmentStatus, AppointmentStatus[]> = {
  confirmed: ['in_service', 'cancelled', 'no_show'],
  in_service: ['completed'],
  completed: [],
  cancelled: [],
  no_show: [],
};

export const STATUS_LABELS: Record<AppointmentStatus, string> = {
  confirmed: 'Confirmado',
  in_service: 'Em Serviço',
  completed: 'Concluído',
  cancelled: 'Cancelado',
  no_show: 'Não Compareceu',
};
