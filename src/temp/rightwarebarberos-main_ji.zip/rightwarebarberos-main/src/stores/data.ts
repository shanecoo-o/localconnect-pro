import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  Service, Barber, Category, BarberId, ServiceId, CategoryId,
  DEFAULT_SERVICES, DEFAULT_BARBERS, DEFAULT_CATEGORIES,
} from '@/lib/types';

// ── ID counters ──
const COUNTERS_KEY = '503barbershop-counters';

interface Counters {
  admin: number;
  barber: number;
  client: number;
}

function getCounters(): Counters {
  const raw = localStorage.getItem(COUNTERS_KEY);
  return raw ? JSON.parse(raw) : { admin: 0, barber: 0, client: 0 };
}

function saveCounters(c: Counters) {
  localStorage.setItem(COUNTERS_KEY, JSON.stringify(c));
}

export function generateId(prefix: 'A' | 'B' | 'C'): string {
  const counters = getCounters();
  const key = prefix === 'A' ? 'admin' : prefix === 'B' ? 'barber' : 'client';
  counters[key] += 1;
  saveCounters(counters);
  return `${prefix}${counters[key].toString().padStart(3, '0')}`;
}

// ── Client type ──
export interface Client {
  id: string;
  name: string;
}

// ── Data store ──
interface DataStore {
  services: Service[];
  barbers: Barber[];
  categories: Category[];
  clients: Client[];

  addService: (s: Omit<Service, 'id'>) => Service;
  removeService: (id: ServiceId) => void;

  addBarber: (name: string) => Barber;
  removeBarber: (id: BarberId) => void;

  addClient: (name: string) => Client;
  removeClient: (id: string) => void;
}

export const useDataStore = create<DataStore>()(
  persist(
    (set, get) => ({
      services: DEFAULT_SERVICES,
      barbers: DEFAULT_BARBERS,
      categories: DEFAULT_CATEGORIES,
      clients: [],

      addService: (s) => {
        const id = `svc_${Date.now().toString(36)}`;
        const newService: Service = { ...s, id };
        set((state) => ({ services: [...state.services, newService] }));
        return newService;
      },
      removeService: (id) => {
        set((state) => ({ services: state.services.filter((s) => s.id !== id) }));
      },

      addBarber: (name) => {
        const id = generateId('B');
        const barber: Barber = { id, name };
        set((state) => ({ barbers: [...state.barbers, barber] }));
        return barber;
      },
      removeBarber: (id) => {
        set((state) => ({ barbers: state.barbers.filter((b) => b.id !== id) }));
      },

      addClient: (name) => {
        const id = generateId('C');
        const client: Client = { id, name };
        set((state) => ({ clients: [...state.clients, client] }));
        return client;
      },
      removeClient: (id) => {
        set((state) => ({ clients: state.clients.filter((c) => c.id !== id) }));
      },
    }),
    { name: '503barbershop-data' }
  )
);
