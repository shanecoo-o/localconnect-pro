import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ServiceId } from '@/lib/types';

export interface CartItem {
  serviceId: ServiceId;
  quantity: number;
}

interface CartStore {
  items: CartItem[];
  addItem: (serviceId: ServiceId) => void;
  removeItem: (serviceId: ServiceId) => void;
  clearCart: () => void;
  getTotalItems: () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (serviceId) => {
        set((state) => {
          const existing = state.items.find((i) => i.serviceId === serviceId);
          if (existing) {
            return {
              items: state.items.map((i) =>
                i.serviceId === serviceId ? { ...i, quantity: i.quantity + 1 } : i
              ),
            };
          }
          return { items: [...state.items, { serviceId, quantity: 1 }] };
        });
      },
      removeItem: (serviceId) => {
        set((state) => {
          const existing = state.items.find((i) => i.serviceId === serviceId);
          if (!existing) return state;
          if (existing.quantity <= 1) {
            return { items: state.items.filter((i) => i.serviceId !== serviceId) };
          }
          return {
            items: state.items.map((i) =>
              i.serviceId === serviceId ? { ...i, quantity: i.quantity - 1 } : i
            ),
          };
        });
      },
      clearCart: () => set({ items: [] }),
      getTotalItems: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
    }),
    { name: '503barbershop-cart' }
  )
);
