import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type UserRole = 'super' | 'admin' | 'barber' | 'client';

export interface AuthUser {
  id: string;
  role: UserRole;
  name: string;
  barberId?: string;
}

interface AuthStore {
  user: AuthUser | null;
  setUser: (user: AuthUser) => void;
  logout: () => void;
  isAuthenticated: () => boolean;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      user: null,
      setUser: (user: AuthUser) => set({ user }),
      logout: () => set({ user: null }),
      isAuthenticated: () => get().user !== null,
    }),
    { name: '503barbershop-auth' }
  )
);
