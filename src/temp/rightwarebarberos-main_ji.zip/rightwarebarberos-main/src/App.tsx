import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useAuthStore } from "@/stores/auth";
import Auth from "./pages/Auth";
import Index from "./pages/Index";
import BarberView from "./pages/BarberView";
import Dashboard from "./pages/Dashboard";
import SuperView from "./pages/SuperView";
import AdminView from "./pages/AdminView";
import ProtectedRoute from "./components/ProtectedRoute";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const RootRedirect = () => {
  const user = useAuthStore((s) => s.user);
  if (!user) return <Navigate to="/auth" replace />;
  const redirects = {
    super: '/super',
    admin: '/admin',
    barber: `/barber/${user.barberId || user.id}`,
    client: '/cliente',
  } as const;
  return <Navigate to={redirects[user.role]} replace />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<RootRedirect />} />
          <Route path="/auth" element={<Auth />} />
          
          <Route path="/cliente" element={
            <ProtectedRoute allowedRoles={['client', 'super', 'admin']}>
              <Index />
            </ProtectedRoute>
          } />
          
          <Route path="/super" element={
            <ProtectedRoute allowedRoles={['super']}>
              <SuperView />
            </ProtectedRoute>
          } />
          
          <Route path="/admin" element={
            <ProtectedRoute allowedRoles={['admin', 'super']}>
              <AdminView />
            </ProtectedRoute>
          } />
          
          <Route path="/barber/:barberId" element={
            <ProtectedRoute allowedRoles={['barber', 'super', 'admin']}>
              <BarberView />
            </ProtectedRoute>
          } />
          
          <Route path="/dashboard" element={
            <ProtectedRoute allowedRoles={['admin', 'super']}>
              <Dashboard />
            </ProtectedRoute>
          } />
          
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
