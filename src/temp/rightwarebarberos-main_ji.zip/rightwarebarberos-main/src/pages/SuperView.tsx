import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Users, Scissors, Settings, Package, Lock } from 'lucide-react';
import { useDataStore } from '@/stores/data';
import { generateId } from '@/stores/data';
import { createUserAccount, removeUserAccount } from '@/lib/auth-service';
import { getAppointments } from '@/lib/appointments';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import AppHeader from '@/components/AppHeader';
import { toast } from 'sonner';

const ADMINS_KEY = '503barbershop-admins';
const TENANTS_KEY = '503barbershop-tenants';

interface Admin { id: string; name: string; tenant?: string; }
interface Tenant { id: string; name: string; }

const getAdmins = (): Admin[] => {
  const raw = localStorage.getItem(ADMINS_KEY);
  return raw ? JSON.parse(raw) : [];
};
const saveAdmins = (a: Admin[]) => localStorage.setItem(ADMINS_KEY, JSON.stringify(a));

const getTenants = (): Tenant[] => {
  const raw = localStorage.getItem(TENANTS_KEY);
  return raw ? JSON.parse(raw) : [{ id: 'default', name: '503BarberShop' }];
};
const saveTenants = (t: Tenant[]) => localStorage.setItem(TENANTS_KEY, JSON.stringify(t));

type Tab = 'admins' | 'barbers' | 'services' | 'tenants';

const SuperView = () => {
  const [tab, setTab] = useState<Tab>('admins');
  const [admins, setAdmins] = useState<Admin[]>(getAdmins());
  const [tenants, setTenants] = useState<Tenant[]>(getTenants());
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminPw, setNewAdminPw] = useState('');
  const [newTenantName, setNewTenantName] = useState('');

  const barbers = useDataStore((s) => s.barbers);
  const services = useDataStore((s) => s.services);
  const categories = useDataStore((s) => s.categories);
  const totalAppointments = getAppointments().length;

  const tabs: { id: Tab; label: string; icon: typeof Users }[] = [
    { id: 'admins', label: 'Admins', icon: Users },
    { id: 'barbers', label: 'Barbeiros', icon: Scissors },
    { id: 'services', label: 'Serviços', icon: Package },
    { id: 'tenants', label: 'Tenants', icon: Settings },
  ];

  const addAdmin = () => {
    if (!newAdminName.trim()) { toast.error('Nome obrigatório'); return; }
    if (!newAdminPw || newAdminPw.length < 8) { toast.error('Password mínimo 8 caracteres'); return; }
    const id = generateId('A');
    const updated = [...admins, { id, name: newAdminName.trim() }];
    setAdmins(updated);
    saveAdmins(updated);
    createUserAccount(id, newAdminName.trim(), newAdminPw, 'admin');
    setNewAdminName('');
    setNewAdminPw('');
    toast.success(`Admin criado: ${newAdminName.trim()} (${id})`);
  };

  const removeAdmin = (id: string) => {
    const updated = admins.filter(a => a.id !== id);
    setAdmins(updated);
    saveAdmins(updated);
    removeUserAccount(id);
    toast.success('Admin removido');
  };

  const addTenant = () => {
    if (!newTenantName.trim()) return;
    const id = Date.now().toString(36);
    const updated = [...tenants, { id, name: newTenantName.trim() }];
    setTenants(updated);
    saveTenants(updated);
    setNewTenantName('');
    toast.success('Tenant criado');
  };

  const resetDemo = () => {
    localStorage.removeItem('takehiro_appointments');
    localStorage.removeItem(ADMINS_KEY);
    localStorage.removeItem(TENANTS_KEY);
    localStorage.removeItem('503barbershop-data');
    localStorage.removeItem('503barbershop-counters');
    localStorage.removeItem('503barbershop-users');
    setAdmins([]);
    setTenants([{ id: 'default', name: '503BarberShop' }]);
    toast.success('Dados demo resetados — recarrega a página');
  };

  const inputClass = "w-full h-10 px-3 rounded-xl border border-border bg-background text-foreground text-sm focus:border-primary focus:outline-none transition-all";

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <AppHeader />
      <main className="max-w-3xl mx-auto px-4 py-6 overflow-hidden">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-bold text-foreground">Painel Super</h2>
            <p className="text-xs text-muted-foreground">Gestão global do SaaS · {totalAppointments} marcações totais</p>
          </div>
          <Button size="sm" variant="outline" onClick={resetDemo} className="text-xs">Reset Demo</Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all
                ${tab === t.id ? 'bg-primary text-primary-foreground shadow-sm' : 'bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/30'}`}>
              <t.icon className="w-3.5 h-3.5" />
              <span className="truncate">{t.label}</span>
            </button>
          ))}
        </div>

        {/* Admins */}
        {tab === 'admins' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="p-4">
              <h3 className="text-sm font-semibold mb-3">Criar Admin</h3>
              <div className="space-y-2">
                <input value={newAdminName} onChange={e => setNewAdminName(e.target.value)} placeholder="Nome" className={inputClass} />
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <input value={newAdminPw} onChange={e => setNewAdminPw(e.target.value)} placeholder="Password (mín. 8 chars)" type="password" className={`${inputClass} pl-9`} />
                </div>
                <Button size="sm" onClick={addAdmin} className="w-full"><Plus className="w-4 h-4 mr-1" /> Criar Admin</Button>
              </div>
              <p className="text-[10px] text-muted-foreground mt-2">ID gerado automaticamente (A###)</p>
            </Card>
            {admins.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">Nenhum admin criado</p>
            ) : (
              <div className="space-y-2">
                {admins.map(admin => (
                  <Card key={admin.id} className="p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{admin.name}</p>
                        <p className="text-xs text-muted-foreground">ID: {admin.id}</p>
                      </div>
                      <button onClick={() => removeAdmin(admin.id)} className="p-2 hover:bg-destructive/10 rounded-xl transition-colors shrink-0">
                        <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                      </button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* Barbers */}
        {tab === 'barbers' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
            <p className="text-xs text-muted-foreground mb-3">Barbeiros (IDs B###) — gerir no Admin</p>
            {barbers.map(b => (
              <Card key={b.id} className="p-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0">
                      <Scissors className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{b.name}</p>
                      <p className="text-xs text-muted-foreground">ID: {b.id}</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs shrink-0">Ativo</Badge>
                </div>
              </Card>
            ))}
          </motion.div>
        )}

        {/* Services */}
        {tab === 'services' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            {categories.map(cat => (
              <div key={cat.id}>
                <h3 className="text-sm font-semibold mb-2 flex items-center gap-2"><span>{cat.icon}</span> {cat.name}</h3>
                <div className="space-y-1.5">
                  {services.filter(s => s.category === cat.id).map(s => (
                    <Card key={s.id} className="p-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{s.name}</p>
                          <p className="text-xs text-muted-foreground">{s.duration} min</p>
                        </div>
                        <span className="text-sm font-semibold shrink-0">{s.price}€</span>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </motion.div>
        )}

        {/* Tenants */}
        {tab === 'tenants' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="p-4">
              <h3 className="text-sm font-semibold mb-3">Criar Tenant</h3>
              <div className="flex gap-2">
                <input value={newTenantName} onChange={e => setNewTenantName(e.target.value)} placeholder="Nome da barbearia" className={inputClass} />
                <Button size="sm" onClick={addTenant} className="h-10 px-4 shrink-0"><Plus className="w-4 h-4" /></Button>
              </div>
            </Card>
            <div className="space-y-2">
              {tenants.map(t => (
                <Card key={t.id} className="p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{t.name}</p>
                      <p className="text-xs text-muted-foreground">ID: {t.id}</p>
                    </div>
                    <Badge variant="secondary" className="text-xs shrink-0">Ativo</Badge>
                  </div>
                </Card>
              ))}
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
};

export default SuperView;
