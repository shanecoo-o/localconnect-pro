import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { CalendarDays, Scissors, Users, Package, XCircle, Plus, Trash2, TrendingUp, Lock } from 'lucide-react';
import { STATUS_LABELS, AppointmentStatus } from '@/lib/types';
import { getAppointmentsByDate, getAppointments, updateAppointmentStatus } from '@/lib/appointments';
import { formatDate } from '@/lib/slots';
import { useDataStore } from '@/stores/data';
import { createUserAccount } from '@/lib/auth-service';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import AppHeader from '@/components/AppHeader';
import { toast } from 'sonner';

const statusColors: Record<AppointmentStatus, string> = {
  confirmed: 'bg-info text-info-foreground',
  in_service: 'bg-warning text-warning-foreground',
  completed: 'bg-success text-success-foreground',
  cancelled: 'bg-destructive text-destructive-foreground',
  no_show: 'bg-muted text-muted-foreground',
};

type Tab = 'appointments' | 'services' | 'barbers' | 'clients' | 'popular';

const AdminView = () => {
  const today = formatDate(new Date());
  const [tab, setTab] = useState<Tab>('appointments');
  const [appointments, setAppointments] = useState(getAppointmentsByDate(today));

  const services = useDataStore((s) => s.services);
  const barbers = useDataStore((s) => s.barbers);
  const categories = useDataStore((s) => s.categories);
  const clients = useDataStore((s) => s.clients);
  const addService = useDataStore((s) => s.addService);
  const removeService = useDataStore((s) => s.removeService);
  const addBarber = useDataStore((s) => s.addBarber);
  const removeBarber = useDataStore((s) => s.removeBarber);
  const addClient = useDataStore((s) => s.addClient);
  const removeClient = useDataStore((s) => s.removeClient);

  // Form states
  const [newSvcName, setNewSvcName] = useState('');
  const [newSvcPrice, setNewSvcPrice] = useState('');
  const [newSvcDuration, setNewSvcDuration] = useState('');
  const [newSvcCategory, setNewSvcCategory] = useState(categories[0]?.id || '');
  const [newBarberName, setNewBarberName] = useState('');
  const [newBarberPw, setNewBarberPw] = useState('');
  const [newClientName, setNewClientName] = useState('');
  const [newClientPw, setNewClientPw] = useState('');

  const refresh = useCallback(() => {
    setAppointments(getAppointmentsByDate(today).sort((a, b) => a.time.localeCompare(b.time)));
  }, [today]);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 5000);
    return () => clearInterval(interval);
  }, [refresh]);

  const handleCancel = (id: string) => {
    try {
      updateAppointmentStatus(id, 'cancelled');
      toast.success('Marcação cancelada');
      refresh();
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  const handleAddService = () => {
    if (!newSvcName.trim() || !newSvcPrice || !newSvcDuration) {
      toast.error('Preenche todos os campos');
      return;
    }
    addService({
      name: newSvcName.trim(),
      price: Number(newSvcPrice),
      duration: Number(newSvcDuration),
      category: newSvcCategory,
    });
    setNewSvcName(''); setNewSvcPrice(''); setNewSvcDuration('');
    toast.success('Serviço adicionado');
  };

  const handleAddBarber = () => {
    if (!newBarberName.trim()) { toast.error('Nome obrigatório'); return; }
    if (!newBarberPw || newBarberPw.length < 8) { toast.error('Password mínimo 8 caracteres'); return; }
    const b = addBarber(newBarberName.trim());
    createUserAccount(b.id, b.name, newBarberPw, 'barber');
    setNewBarberName('');
    setNewBarberPw('');
    toast.success(`Barbeiro criado: ${b.name} (${b.id})`);
  };

  const handleAddClient = () => {
    if (!newClientName.trim()) { toast.error('Nome obrigatório'); return; }
    if (!newClientPw || newClientPw.length < 8) { toast.error('Password mínimo 8 caracteres'); return; }
    const c = addClient(newClientName.trim());
    createUserAccount(c.id, c.name, newClientPw, 'client');
    setNewClientName('');
    setNewClientPw('');
    toast.success(`Cliente criado: ${c.name} (${c.id})`);
  };

  // Popular services
  const allAppointments = getAppointments();
  const serviceCount = allAppointments.reduce<Record<string, number>>((acc, a) => {
    if (a.status !== 'cancelled') {
      acc[a.serviceId] = (acc[a.serviceId] || 0) + 1;
    }
    return acc;
  }, {});
  const popularServices = Object.entries(serviceCount)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10)
    .map(([id, count]) => ({ service: services.find(s => s.id === id), count }))
    .filter(x => x.service);

  const totalRevenue = appointments
    .filter(a => a.status !== 'cancelled' && a.status !== 'no_show')
    .reduce((sum, a) => sum + (services.find(s => s.id === a.serviceId)?.price || 0), 0);

  const tabs: { id: Tab; label: string; icon: typeof CalendarDays }[] = [
    { id: 'appointments', label: 'Marcações', icon: CalendarDays },
    { id: 'services', label: 'Serviços', icon: Package },
    { id: 'barbers', label: 'Barbeiros', icon: Scissors },
    { id: 'clients', label: 'Clientes', icon: Users },
    { id: 'popular', label: 'Top', icon: TrendingUp },
  ];

  const inputClass = "w-full h-10 px-3 rounded-xl border border-border bg-background text-foreground text-sm focus:border-primary focus:outline-none transition-all";

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <AppHeader />
      <main className="max-w-3xl mx-auto px-4 py-6 overflow-hidden">
        <div className="mb-6">
          <h2 className="text-lg font-bold text-foreground">Painel Admin</h2>
          <p className="text-xs text-muted-foreground">
            {new Date().toLocaleDateString('pt-PT', { weekday: 'long', day: 'numeric', month: 'long' })}
            {' · '}{appointments.length} marcações · {totalRevenue}€ receita esperada
          </p>
        </div>

        {/* Responsive tab grid */}
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 mb-6">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all
                ${tab === t.id ? 'bg-primary text-primary-foreground shadow-sm' : 'bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/30'}`}>
              <t.icon className="w-3.5 h-3.5" />
              <span className="truncate">{t.label}</span>
            </button>
          ))}
        </div>

        {/* Appointments */}
        {tab === 'appointments' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            {barbers.map(barber => {
              const barberApts = appointments.filter(a => a.barberId === barber.id);
              return (
                <div key={barber.id}>
                  <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <Scissors className="w-3.5 h-3.5 text-primary" />{barber.name}
                    <Badge variant="secondary" className="text-[10px]">{barberApts.length}</Badge>
                  </h3>
                  {barberApts.length === 0 ? (
                    <p className="text-xs text-muted-foreground mb-4">Sem marcações</p>
                  ) : (
                    <div className="space-y-2 mb-4">
                      {barberApts.map(apt => {
                        const service = services.find(s => s.id === apt.serviceId);
                        return (
                          <Card key={apt.id} className="p-3">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-3 min-w-0">
                                <span className="font-mono text-sm font-medium shrink-0">{apt.time}</span>
                                <div className="min-w-0">
                                  <p className="text-sm font-medium truncate">{apt.clientName}</p>
                                  <p className="text-xs text-muted-foreground truncate">{service?.name} · {service?.price === 0 ? 'Grátis' : `${service?.price}€`}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <Badge className={`${statusColors[apt.status]} text-[10px]`} variant="secondary">{STATUS_LABELS[apt.status]}</Badge>
                                {apt.status === 'confirmed' && (
                                  <button onClick={() => handleCancel(apt.id)} className="p-1.5 rounded-lg hover:bg-destructive/10 transition-colors">
                                    <XCircle className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </Card>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </motion.div>
        )}

        {/* Services */}
        {tab === 'services' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="p-4">
              <h3 className="text-sm font-semibold mb-3">Adicionar Serviço</h3>
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <input value={newSvcName} onChange={e => setNewSvcName(e.target.value)} placeholder="Nome" className={inputClass} />
                  <select value={newSvcCategory} onChange={e => setNewSvcCategory(e.target.value)} className={inputClass}>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input value={newSvcPrice} onChange={e => setNewSvcPrice(e.target.value)} placeholder="Preço €" type="number" className={inputClass} />
                  <input value={newSvcDuration} onChange={e => setNewSvcDuration(e.target.value)} placeholder="Duração min" type="number" className={inputClass} />
                </div>
                <Button size="sm" onClick={handleAddService} className="w-full"><Plus className="w-4 h-4 mr-1" /> Adicionar</Button>
              </div>
            </Card>

            {categories.map(cat => (
              <div key={cat.id}>
                <h3 className="text-sm font-semibold mb-2">{cat.icon} {cat.name}</h3>
                <div className="space-y-1.5">
                  {services.filter(s => s.category === cat.id).map(s => (
                    <Card key={s.id} className="p-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{s.name}</p>
                          <p className="text-xs text-muted-foreground">{s.duration} min</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-sm font-semibold">{s.price}€</span>
                          <button onClick={() => { removeService(s.id); toast.success('Serviço removido'); }}
                            className="p-1.5 rounded-lg hover:bg-destructive/10 transition-colors">
                            <Trash2 className="w-3.5 h-3.5 text-muted-foreground hover:text-destructive" />
                          </button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </motion.div>
        )}

        {/* Barbers */}
        {tab === 'barbers' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="p-4">
              <h3 className="text-sm font-semibold mb-3">Adicionar Barbeiro</h3>
              <div className="space-y-2">
                <input value={newBarberName} onChange={e => setNewBarberName(e.target.value)} placeholder="Nome" className={inputClass} />
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <input value={newBarberPw} onChange={e => setNewBarberPw(e.target.value)} placeholder="Password (mín. 8 chars)" type="password" className={`${inputClass} pl-9`} />
                </div>
                <Button size="sm" onClick={handleAddBarber} className="w-full"><Plus className="w-4 h-4 mr-1" /> Criar Barbeiro</Button>
              </div>
            </Card>
            <div className="space-y-2">
              {barbers.map(b => (
                <Card key={b.id} className="p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0">
                        <Scissors className="w-4 h-4 text-muted-foreground" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{b.name}</p>
                        <p className="text-xs text-muted-foreground">ID: {b.id}</p>
                      </div>
                    </div>
                    <button onClick={() => { removeBarber(b.id); toast.success('Barbeiro removido'); }}
                      className="p-2 hover:bg-destructive/10 rounded-xl transition-colors shrink-0">
                      <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                    </button>
                  </div>
                </Card>
              ))}
            </div>
          </motion.div>
        )}

        {/* Clients */}
        {tab === 'clients' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="p-4">
              <h3 className="text-sm font-semibold mb-3">Criar Cliente</h3>
              <div className="space-y-2">
                <input value={newClientName} onChange={e => setNewClientName(e.target.value)} placeholder="Nome" className={inputClass} />
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <input value={newClientPw} onChange={e => setNewClientPw(e.target.value)} placeholder="Password (mín. 8 chars)" type="password" className={`${inputClass} pl-9`} />
                </div>
                <Button size="sm" onClick={handleAddClient} className="w-full"><Plus className="w-4 h-4 mr-1" /> Criar Cliente</Button>
              </div>
            </Card>
            {clients.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">Nenhum cliente criado</p>
            ) : (
              <div className="space-y-2">
                {clients.map(c => (
                  <Card key={c.id} className="p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{c.name}</p>
                        <p className="text-xs text-muted-foreground">ID: {c.id}</p>
                      </div>
                      <button onClick={() => { removeClient(c.id); toast.success('Cliente removido'); }}
                        className="p-2 hover:bg-destructive/10 rounded-xl transition-colors shrink-0">
                        <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                      </button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* Popular */}
        {tab === 'popular' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" /> Serviços Mais Adquiridos
            </h3>
            {popularServices.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">Sem dados suficientes</p>
            ) : (
              popularServices.map(({ service: svc, count }, i) => (
                <Card key={svc!.id} className="p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{svc!.name}</p>
                        <p className="text-xs text-muted-foreground">{svc!.price}€ · {svc!.duration} min</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className="shrink-0">{count}×</Badge>
                  </div>
                </Card>
              ))
            )}
          </motion.div>
        )}
      </main>
    </div>
  );
};

export default AdminView;
