import { useState, useEffect, useCallback } from 'react';
import { getAppointmentsByDate } from '@/lib/appointments';
import { formatDate } from '@/lib/slots';
import { Appointment, STATUS_LABELS, AppointmentStatus } from '@/lib/types';
import { useDataStore } from '@/stores/data';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import AppHeader from '@/components/AppHeader';

const statusColors: Record<AppointmentStatus, string> = {
  confirmed: 'bg-info text-info-foreground',
  in_service: 'bg-warning text-warning-foreground',
  completed: 'bg-success text-success-foreground',
  cancelled: 'bg-destructive text-destructive-foreground',
  no_show: 'bg-muted text-muted-foreground',
};

const Dashboard = () => {
  const today = formatDate(new Date());
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const barbers = useDataStore((s) => s.barbers);
  const services = useDataStore((s) => s.services);

  const refresh = useCallback(() => {
    const data = getAppointmentsByDate(today);
    data.sort((a, b) => a.time.localeCompare(b.time));
    setAppointments(data);
  }, [today]);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 5000);
    return () => clearInterval(interval);
  }, [refresh]);

  const totalRevenue = appointments
    .filter(a => a.status !== 'cancelled' && a.status !== 'no_show')
    .reduce((sum, a) => sum + (services.find(s => s.id === a.serviceId)?.price || 0), 0);

  const completedRevenue = appointments
    .filter(a => a.status === 'completed')
    .reduce((sum, a) => sum + (services.find(s => s.id === a.serviceId)?.price || 0), 0);

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />
      <main className="container max-w-2xl mx-auto px-4 py-6">
        <h2 className="text-lg font-semibold mb-1">Painel do Dia</h2>
        <p className="text-sm text-muted-foreground mb-5">
          {new Date().toLocaleDateString('pt-PT', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
        </p>

        <div className="grid grid-cols-2 gap-3 mb-6">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground mb-1">Receita Esperada</p>
            <p className="text-2xl font-bold">{totalRevenue}€</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground mb-1">Receita Concluída</p>
            <p className="text-2xl font-bold text-success">{completedRevenue}€</p>
          </Card>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground mb-1">Total Marcações</p>
            <p className="text-2xl font-bold">{appointments.length}</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground mb-1">Concluídas</p>
            <p className="text-2xl font-bold">{appointments.filter(a => a.status === 'completed').length}</p>
          </Card>
        </div>

        {barbers.map(barber => {
          const barberApts = appointments.filter(a => a.barberId === barber.id);
          return (
            <div key={barber.id} className="mb-6">
              <h3 className="font-semibold mb-3">{barber.name}</h3>
              {barberApts.length === 0 ? (
                <p className="text-sm text-muted-foreground">Sem marcações.</p>
              ) : (
                <div className="space-y-2">
                  {barberApts.map(apt => {
                    const service = services.find(s => s.id === apt.serviceId);
                    return (
                      <Card key={apt.id} className="p-3 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-sm font-medium">{apt.time}</span>
                          <div>
                            <p className="text-sm font-medium">{apt.clientName}</p>
                            <p className="text-xs text-muted-foreground">{service?.name} · {service?.price === 0 ? 'Grátis' : `${service?.price}€`}</p>
                          </div>
                        </div>
                        <Badge className={statusColors[apt.status]} variant="secondary">{STATUS_LABELS[apt.status]}</Badge>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </main>
    </div>
  );
};

export default Dashboard;
