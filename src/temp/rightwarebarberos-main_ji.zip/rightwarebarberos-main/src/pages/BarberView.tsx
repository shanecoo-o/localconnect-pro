import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { getAppointmentsByBarberAndDate, updateAppointmentStatus } from '@/lib/appointments';
import { formatDate } from '@/lib/slots';
import { Appointment, STATUS_LABELS, VALID_TRANSITIONS, BarberId, AppointmentStatus } from '@/lib/types';
import { useDataStore } from '@/stores/data';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, CheckCircle, XCircle, UserX } from 'lucide-react';
import { toast } from 'sonner';
import AppHeader from '@/components/AppHeader';

const statusColors: Record<AppointmentStatus, string> = {
  confirmed: 'bg-info text-info-foreground',
  in_service: 'bg-warning text-warning-foreground',
  completed: 'bg-success text-success-foreground',
  cancelled: 'bg-destructive text-destructive-foreground',
  no_show: 'bg-muted text-muted-foreground',
};

const BarberView = () => {
  const { barberId } = useParams<{ barberId: string }>();
  const today = formatDate(new Date());
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const barbers = useDataStore((s) => s.barbers);
  const services = useDataStore((s) => s.services);

  const barber = barbers.find(b => b.id === barberId);

  const refresh = useCallback(() => {
    if (barberId) {
      const data = getAppointmentsByBarberAndDate(barberId as BarberId, today);
      data.sort((a, b) => a.time.localeCompare(b.time));
      setAppointments(data);
    }
  }, [barberId, today]);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 5000);
    return () => clearInterval(interval);
  }, [refresh]);

  const handleTransition = (id: string, newStatus: AppointmentStatus) => {
    try {
      updateAppointmentStatus(id, newStatus);
      toast.success(`Estado atualizado: ${STATUS_LABELS[newStatus]}`);
      refresh();
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  if (!barber) {
    return <div className="min-h-screen bg-background flex items-center justify-center text-muted-foreground">Barbeiro não encontrado.</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />
      <main className="container max-w-lg mx-auto px-4 py-6">
        <h2 className="text-lg font-semibold mb-1">{barber.name}</h2>
        <p className="text-sm text-muted-foreground mb-5">Hoje — {new Date().toLocaleDateString('pt-PT', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
        {appointments.length === 0 ? (
          <p className="text-muted-foreground text-center py-12">Sem marcações para hoje.</p>
        ) : (
          <div className="space-y-3">
            {appointments.map(apt => {
              const service = services.find(s => s.id === apt.serviceId);
              const transitions = VALID_TRANSITIONS[apt.status];
              return (
                <Card key={apt.id} className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="text-xl font-semibold tabular-nums">{apt.time}</p>
                      <p className="text-sm text-muted-foreground">{apt.clientName}</p>
                    </div>
                    <Badge className={statusColors[apt.status]}>{STATUS_LABELS[apt.status]}</Badge>
                  </div>
                  <p className="text-sm mb-3">{service?.name} · {service?.price === 0 ? 'Grátis' : `${service?.price}€`}</p>
                  {transitions.length > 0 && (
                    <div className="flex gap-2">
                      {apt.status === 'confirmed' && (
                        <>
                          <Button size="sm" onClick={() => handleTransition(apt.id, 'in_service')} className="flex-1">
                            <Play className="w-4 h-4 mr-1" /> Iniciar
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handleTransition(apt.id, 'cancelled')}>
                            <XCircle className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handleTransition(apt.id, 'no_show')}>
                            <UserX className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                      {apt.status === 'in_service' && (
                        <Button size="sm" onClick={() => handleTransition(apt.id, 'completed')} className="flex-1">
                          <CheckCircle className="w-4 h-4 mr-1" /> Concluir
                        </Button>
                      )}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
};

export default BarberView;
