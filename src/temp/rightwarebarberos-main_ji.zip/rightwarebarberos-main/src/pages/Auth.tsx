import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { LogIn, UserPlus, Copy, CheckCircle2, Eye, EyeOff } from 'lucide-react';
import { useAuthStore, UserRole } from '@/stores/auth';
import { loginUser, registerClient, validatePassword, validateName } from '@/lib/auth-service';
import { generateId } from '@/stores/data';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

type AuthTab = 'login' | 'register';

const Auth = () => {
  const [tab, setTab] = useState<AuthTab>('login');

  // Login state
  const [loginId, setLoginId] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showLoginPw, setShowLoginPw] = useState(false);

  // Register state
  const [regName, setRegName] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirm, setRegConfirm] = useState('');
  const [regError, setRegError] = useState('');
  const [showRegPw, setShowRegPw] = useState(false);
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [idCopied, setIdCopied] = useState(false);

  const setUser = useAuthStore((s) => s.setUser);
  const navigate = useNavigate();

  const getRedirect = (role: UserRole, id: string): string => {
    const redirects: Record<UserRole, string> = {
      super: '/super',
      admin: '/admin',
      barber: `/barber/${id}`,
      client: '/cliente',
    };
    return redirects[role];
  };

  const handleLogin = () => {
    setLoginError('');
    const result = loginUser(loginId, loginPassword);
    if (!result.success) {
      setLoginError(result.error || 'Erro de autenticação');
      return;
    }
    const u = result.user!;
    setUser({
      id: u.id,
      role: u.role,
      name: u.name,
      barberId: u.role === 'barber' ? u.id : undefined,
    });
    toast.success('Bem-vindo!', { description: `Sessão iniciada como ${u.name}` });
    navigate(getRedirect(u.role, u.id));
  };

  const handleRegister = () => {
    setRegError('');
    const nameErr = validateName(regName);
    if (nameErr) { setRegError(nameErr); return; }
    const pwErr = validatePassword(regPassword);
    if (pwErr) { setRegError(pwErr); return; }
    if (regPassword !== regConfirm) { setRegError('As passwords não coincidem'); return; }

    const clientId = generateId('C');
    const result = registerClient(regName, regPassword, clientId);
    if (!result.success) { setRegError(result.error || 'Erro ao criar conta'); return; }

    setCreatedId(result.user!.id);
    toast.success('Conta criada com sucesso!');
  };

  const copyId = () => {
    if (createdId) {
      navigator.clipboard.writeText(createdId);
      setIdCopied(true);
      toast.success('ID copiado!');
      setTimeout(() => setIdCopied(false), 2000);
    }
  };

  const goToLoginAfterRegister = () => {
    setTab('login');
    setLoginId(createdId || '');
    setCreatedId(null);
    setRegName('');
    setRegPassword('');
    setRegConfirm('');
  };

  const inputClass =
    'w-full h-12 px-4 rounded-2xl border border-border bg-card text-foreground text-sm placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary/30 transition-all';

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-sm"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-foreground tracking-tight">
            503<span className="text-primary">BarberShop</span>
          </h1>
          <p className="text-sm text-muted-foreground mt-2">O teu estilo, a tua agenda</p>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-card border border-border rounded-2xl p-1 mb-6">
          {([
            { id: 'login' as AuthTab, label: 'Entrar', icon: LogIn },
            { id: 'register' as AuthTab, label: 'Criar conta', icon: UserPlus },
          ]).map((t) => (
            <button
              key={t.id}
              onClick={() => { setTab(t.id); setLoginError(''); setRegError(''); setCreatedId(null); }}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium transition-all duration-200
                ${tab === t.id
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
                }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {/* ── Login Tab ── */}
          {tab === 'login' && (
            <motion.div
              key="login"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
              className="space-y-4"
            >
              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">ID</label>
                <input
                  type="text"
                  value={loginId}
                  onChange={(e) => setLoginId(e.target.value)}
                  placeholder="O teu ID (ex: C001)"
                  autoFocus
                  className={inputClass}
                  onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                />
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">Password</label>
                <div className="relative">
                  <input
                    type={showLoginPw ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="A tua password"
                    className={inputClass}
                    onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPw(!showLoginPw)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showLoginPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {loginError && (
                <p className="text-xs text-destructive bg-destructive/10 rounded-xl px-3 py-2">{loginError}</p>
              )}

              <Button
                onClick={handleLogin}
                className="w-full h-12 rounded-2xl text-sm font-semibold bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Entrar
              </Button>

              <p className="text-[10px] text-muted-foreground/60 text-center">
                Não tens conta? Clica em "Criar conta" acima.
              </p>
            </motion.div>
          )}

          {/* ── Register Tab ── */}
          {tab === 'register' && !createdId && (
            <motion.div
              key="register"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
              className="space-y-4"
            >
              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">Nome completo</label>
                <input
                  type="text"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="O teu nome completo"
                  autoFocus
                  className={inputClass}
                />
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">Password</label>
                <div className="relative">
                  <input
                    type={showRegPw ? 'text' : 'password'}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Mínimo 8 caracteres"
                    className={inputClass}
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPw(!showRegPw)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showRegPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">Confirmar password</label>
                <input
                  type="password"
                  value={regConfirm}
                  onChange={(e) => setRegConfirm(e.target.value)}
                  placeholder="Repete a password"
                  className={inputClass}
                  onKeyDown={(e) => e.key === 'Enter' && handleRegister()}
                />
              </div>

              {regError && (
                <p className="text-xs text-destructive bg-destructive/10 rounded-xl px-3 py-2">{regError}</p>
              )}

              <Button
                onClick={handleRegister}
                className="w-full h-12 rounded-2xl text-sm font-semibold bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Criar conta
              </Button>

              <p className="text-[10px] text-muted-foreground/60 text-center">
                Será gerado um ID único para ti. Guarda-o bem!
              </p>
            </motion.div>
          )}

          {/* ── Success: Show generated ID ── */}
          {tab === 'register' && createdId && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="space-y-5 text-center"
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8 text-primary" />
              </div>

              <div>
                <h3 className="text-lg font-bold text-foreground">Conta criada!</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Guarda o teu ID — vais precisar dele para entrar.
                </p>
              </div>

              <div className="bg-card border-2 border-primary/30 rounded-2xl p-5">
                <p className="text-[10px] text-muted-foreground mb-1 uppercase tracking-wider">O teu ID</p>
                <p className="text-3xl font-mono font-bold text-primary tracking-widest">{createdId}</p>
              </div>

              <button
                onClick={copyId}
                className="flex items-center gap-2 mx-auto text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                {idCopied ? <CheckCircle2 className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
                {idCopied ? 'Copiado!' : 'Copiar ID'}
              </button>

              <Button
                onClick={goToLoginAfterRegister}
                className="w-full h-12 rounded-2xl text-sm font-semibold bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Ir para o login
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default Auth;
