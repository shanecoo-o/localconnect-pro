import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, ArrowRight } from 'lucide-react';
import { CategoryId } from '@/lib/types';
import { useCartStore } from '@/stores/cart';
import { useDataStore } from '@/stores/data';
import CategoryGrid from '@/components/CategoryGrid';
import CartSidebar from '@/components/CartSidebar';
import BookingFlow from '@/components/BookingFlow';
import AppHeader from '@/components/AppHeader';

const Index = () => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryId | null>(null);
  const [bookingOpen, setBookingOpen] = useState(false);
  const totalItems = useCartStore((s) => s.getTotalItems());
  const items = useCartStore((s) => s.items);
  const services = useDataStore((s) => s.services);

  const total = items.reduce((sum, item) => {
    const svc = services.find(s => s.id === item.serviceId);
    return sum + (svc?.price ?? 0) * item.quantity;
  }, 0);

  const totalDuration = items.reduce((sum, item) => {
    const svc = services.find(s => s.id === item.serviceId);
    return sum + (svc?.duration ?? 0) * item.quantity;
  }, 0);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <AppHeader />
      <div className="flex flex-1 max-w-6xl mx-auto w-full overflow-hidden">
        <main className="flex-1 flex flex-col overflow-hidden">
          <div className="px-4 sm:px-6 lg:px-8 pt-6 lg:pt-8 pb-2">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
              <h1 className="text-xl sm:text-2xl font-bold text-foreground mb-1 text-center lg:text-left">Escolhe o serviço</h1>
              <p className="text-sm text-muted-foreground mb-4 text-center lg:text-left">Seleciona os serviços que pretendes</p>
            </motion.div>
          </div>
          <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pb-4 overscroll-contain [-webkit-overflow-scrolling:touch]">
            <CategoryGrid selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} />
          </div>
        </main>
        <aside className="hidden lg:block w-80 border-l border-border bg-card/50 sticky top-14 h-[calc(100vh-3.5rem)]">
          <CartSidebar onBooking={() => setBookingOpen(true)} />
        </aside>
      </div>

      <AnimatePresence>
        {totalItems > 0 && (
          <motion.div initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 80, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-card/95 backdrop-blur-xl border-t border-primary/20 px-4 py-3 safe-area-bottom">
            <div className="flex items-center justify-between max-w-lg mx-auto">
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <motion.span key={total} initial={{ scale: 1.15, color: 'hsl(1, 100%, 44%)' }}
                    animate={{ scale: 1, color: 'hsl(0, 0%, 100%)' }} transition={{ duration: 0.35 }}
                    className="text-lg font-bold text-foreground tabular-nums">{total}€</motion.span>
                  <span className="text-xs text-muted-foreground">· {totalItems} {totalItems === 1 ? 'serviço' : 'serviços'}</span>
                </div>
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {totalDuration} min
                </span>
              </div>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => setBookingOpen(true)}
                className="flex items-center gap-2 h-11 px-6 rounded-2xl bg-primary text-primary-foreground font-semibold text-sm glow-red active:scale-95 transition-transform">
                Agendar <ArrowRight className="w-4 h-4" />
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <BookingFlow open={bookingOpen} onClose={() => setBookingOpen(false)} />
    </div>
  );
};

export default Index;
