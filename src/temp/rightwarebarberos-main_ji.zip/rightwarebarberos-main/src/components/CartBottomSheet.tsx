import { motion, AnimatePresence, useDragControls } from 'framer-motion';
import { ShoppingBag, X } from 'lucide-react';
import { useCartStore } from '@/stores/cart';
import CartSidebar from './CartSidebar';

interface CartBottomSheetProps {
  open: boolean;
  onClose: () => void;
}

const CartBottomSheet = ({ open, onClose }: CartBottomSheetProps) => {
  const totalItems = useCartStore((s) => s.getTotalItems());

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
          />

          {/* Sheet */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            drag="y"
            dragConstraints={{ top: 0 }}
            dragElastic={0.2}
            onDragEnd={(_, info) => {
              if (info.offset.y > 100) onClose();
            }}
            className="fixed bottom-0 left-0 right-0 z-50 max-h-[80vh] rounded-t-3xl
                       bg-card border-t border-border overflow-hidden"
          >
            {/* Handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
            </div>

            <div className="h-[70vh] overflow-y-auto">
              <CartSidebar />
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartBottomSheet;
