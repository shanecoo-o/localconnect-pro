import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, Trash2, Clock, ArrowRight } from 'lucide-react';
import { useCartStore } from '@/stores/cart';
import { useDataStore } from '@/stores/data';
import { Button } from '@/components/ui/button';

interface CartSidebarProps {
  onBooking?: () => void;
}

const CartSidebar = ({ onBooking }: CartSidebarProps) => {
  const { items, removeItem, clearCart } = useCartStore();
  const services = useDataStore((s) => s.services);

  const total = items.reduce((sum, item) => {
    const svc = services.find(s => s.id === item.serviceId);
    return sum + (svc?.price ?? 0) * item.quantity;
  }, 0);

  const totalDuration = items.reduce((sum, item) => {
    const svc = services.find(s => s.id === item.serviceId);
    return sum + (svc?.duration ?? 0) * item.quantity;
  }, 0);

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between px-5 py-4 border-b border-border">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-foreground text-sm">Resumo</h3>
        </div>
        {items.length > 0 && (
          <button onClick={clearCart} className="text-xs text-muted-foreground hover:text-destructive transition-colors">
            Limpar
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-3">
        <AnimatePresence mode="popLayout">
          {items.length === 0 ? (
            <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center h-full text-center py-12">
              <ShoppingBag className="w-8 h-8 text-muted-foreground/30 mb-3" />
              <p className="text-xs text-muted-foreground">Nenhum serviço adicionado</p>
            </motion.div>
          ) : (
            items.map((item) => {
              const service = services.find((s) => s.id === item.serviceId);
              if (!service) return null;
              return (
                <motion.div key={item.serviceId} layout
                  initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                  className="flex items-center justify-between py-3 border-b border-border/50 last:border-0">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{service.name}</p>
                    <p className="text-xs text-muted-foreground">{item.quantity}× · {service.duration * item.quantity} min</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-foreground tabular-nums">{service.price * item.quantity}€</span>
                    <button onClick={() => removeItem(item.serviceId)}
                      className="p-1 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>

      {items.length > 0 && (
        <div className="border-t border-border px-5 py-4 space-y-3">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> Duração</span>
            <span>{totalDuration} min</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Total</span>
            <motion.span key={total} initial={{ scale: 1.2, color: 'hsl(1, 100%, 44%)' }}
              animate={{ scale: 1, color: 'hsl(0, 0%, 100%)' }} transition={{ duration: 0.4 }}
              className="text-lg font-bold text-foreground tabular-nums">{total}€</motion.span>
          </div>
          <Button onClick={onBooking}
            className="w-full h-11 rounded-xl text-sm font-semibold glow-red bg-primary hover:bg-primary/90 text-primary-foreground">
            Agendar <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default CartSidebar;
