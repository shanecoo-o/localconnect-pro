import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Calendar, Clock, User, Check } from 'lucide-react';
import { BarberId, ServiceId } from '@/lib/types';
import { useDataStore } from '@/stores/data';
import { generateSlots, formatDate } from '@/lib/slots';
import { createAppointment } from '@/lib/appointments';
import { useCartStore } from '@/stores/cart';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

type Step = 'barber' | 'date' | 'time' | 'confirm';

interface BookingFlowProps {
  open: boolean;
  onClose: () => void;
}

const BookingFlow = ({ open, onClose }: BookingFlowProps) => {
  const { items, clearCart } = useCartStore();
  const services = useDataStore((s) => s.services);
  const barbers = useDataStore((s) => s.barbers);

  const [step, setStep] = useState<Step>('barber');
  const [selectedBarber, setSelectedBarber] = useState<BarberId | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(formatDate(new Date()));
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [clientName, setClientName] = useState('');

  const firstItem = items[0];
  const service = firstItem ? services.find(s => s.id === firstItem.serviceId) : null;

  const dates = useMemo(() => {
    const result: { date: string; label: string; dayName: string }[] = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date();
      d.setDate(d.getDate() + i);
      result.push({
        date: formatDate(d),
        label: d.getDate().toString(),
        dayName: d.toLocaleDateString('pt-PT', { weekday: 'short' }).replace('.', ''),
      });
    }
    return result;
  }, []);

  const slots = useMemo(() => {
    if (!selectedBarber || !service) return [];
    return generateSlots(selectedBarber, selectedDate, service.id, services);
  }, [selectedBarber, selectedDate, service, services]);

  const reset = () => {
    setStep('barber');
    setSelectedBarber(null);
    setSelectedDate(formatDate(new Date()));
    setSelectedTime(null);
    setClientName('');
  };

  const handleClose = () => { reset(); onClose(); };

  const handleConfirm = () => {
    if (!selectedBarber || !selectedTime || !service) return;
    try {
      createAppointment(service.id, selectedBarber, selectedDate, selectedTime, clientName || 'Cliente', services);
      toast.success('Marcação confirmada!', {
        description: `${service.name} às ${selectedTime} com ${barbers.find(b => b.id === selectedBarber)?.name}`,
      });
      clearCart();
      handleClose();
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  const stepTitle: Record<Step, string> = {
    barber: 'Seleciona o barbeiro',
    date: 'Escolhe a data',
    time: 'Escolhe a hora',
    confirm: 'Confirmar marcação',
  };

  const goBack = () => {
    if (step === 'date') setStep('barber');
    else if (step === 'time') setStep('date');
    else if (step === 'confirm') setStep('time');
    else handleClose();
  };

  if (!open) return null;

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={handleClose} className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm" />
          <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed bottom-0 left-0 right-0 z-50 max-h-[85vh] rounded-t-3xl bg-card border-t border-border overflow-hidden flex flex-col">
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-muted-foreground/30" />
            </div>
            <div className="flex items-center gap-3 px-5 py-3 border-b border-border">
              <button onClick={goBack} className="p-1.5 rounded-xl hover:bg-muted transition-colors">
                <ArrowLeft className="w-4 h-4 text-muted-foreground" />
              </button>
              <h3 className="font-semibold text-foreground text-sm">{stepTitle[step]}</h3>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4">
              <AnimatePresence mode="wait">
                {step === 'barber' && (
                  <motion.div key="barber" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-3">
                    {barbers.map((barber) => (
                      <button key={barber.id} onClick={() => { setSelectedBarber(barber.id); setStep('date'); }}
                        className={`w-full flex items-center gap-4 p-4 rounded-2xl border transition-all duration-200
                          ${selectedBarber === barber.id ? 'border-primary bg-primary/10 glow-red' : 'border-border bg-card hover:border-primary/30'}`}>
                        <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
                          <User className="w-5 h-5 text-muted-foreground" />
                        </div>
                        <span className="font-medium text-foreground">{barber.name}</span>
                      </button>
                    ))}
                  </motion.div>
                )}

                {step === 'date' && (
                  <motion.div key="date" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
                    <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
                      {dates.map((d) => (
                        <button key={d.date} onClick={() => { setSelectedDate(d.date); setSelectedTime(null); setStep('time'); }}
                          className={`flex-shrink-0 flex flex-col items-center w-14 py-3 rounded-2xl border transition-all duration-200
                            ${selectedDate === d.date ? 'border-primary bg-primary/10 text-foreground' : 'border-border bg-card hover:border-primary/30 text-muted-foreground'}`}>
                          <span className="text-[10px] uppercase font-medium">{d.dayName}</span>
                          <span className="text-lg font-bold mt-1">{d.label}</span>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}

                {step === 'time' && (
                  <motion.div key="time" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
                    <p className="text-xs text-muted-foreground">
                      {service?.name} · {service?.duration} min ·{' '}
                      {new Date(selectedDate + 'T00:00').toLocaleDateString('pt-PT', { weekday: 'long', day: 'numeric', month: 'long' })}
                    </p>
                    {slots.length === 0 ? (
                      <div className="text-center py-12">
                        <Clock className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground">Sem horários disponíveis</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                        {slots.map((slot) => (
                          <button key={slot} onClick={() => { setSelectedTime(slot); setStep('confirm'); }}
                            className={`py-3 rounded-xl text-sm font-medium border transition-all duration-200
                              ${selectedTime === slot ? 'border-primary bg-primary text-primary-foreground glow-red' : 'border-border bg-card hover:border-primary/30 text-foreground hover:bg-muted/50'}`}>
                            {slot}
                          </button>
                        ))}
                      </div>
                    )}
                  </motion.div>
                )}

                {step === 'confirm' && (
                  <motion.div key="confirm" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                    <div className="rounded-2xl border border-border bg-background p-4 space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Serviço</span>
                        <span className="font-medium text-foreground">{service?.name}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Barbeiro</span>
                        <span className="font-medium text-foreground">{barbers.find(b => b.id === selectedBarber)?.name}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Data</span>
                        <span className="font-medium text-foreground">
                          {new Date(selectedDate + 'T00:00').toLocaleDateString('pt-PT', { day: 'numeric', month: 'long' })}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Hora</span>
                        <span className="font-medium text-foreground">{selectedTime}</span>
                      </div>
                      <div className="flex justify-between text-sm border-t border-border pt-3">
                        <span className="text-muted-foreground">Total</span>
                        <span className="font-bold text-foreground text-base">{service?.price === 0 ? 'Grátis' : `${service?.price}€`}</span>
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1.5 block">Nome (opcional)</label>
                      <input type="text" value={clientName} onChange={(e) => setClientName(e.target.value)}
                        placeholder="O teu nome"
                        className="w-full h-11 px-4 rounded-xl border border-border bg-background text-foreground text-sm placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary/30 transition-all" />
                    </div>
                    <Button onClick={handleConfirm}
                      className="w-full h-12 rounded-xl text-sm font-semibold glow-red bg-primary hover:bg-primary/90 text-primary-foreground">
                      <Check className="w-4 h-4 mr-2" /> Confirmar Marcação
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default BookingFlow;
