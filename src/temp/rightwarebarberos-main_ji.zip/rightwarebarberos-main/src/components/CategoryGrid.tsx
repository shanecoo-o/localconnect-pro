import { motion, AnimatePresence } from 'framer-motion';
import { CategoryId } from '@/lib/types';
import { useDataStore } from '@/stores/data';
import { ServiceCard } from './ServiceCard';

interface CategoryGridProps {
  selectedCategory: CategoryId | null;
  onSelectCategory: (id: CategoryId | null) => void;
}

const transition = { type: 'spring' as const, stiffness: 300, damping: 30 };

const CategoryGrid = ({ selectedCategory, onSelectCategory }: CategoryGridProps) => {
  const categories = useDataStore((s) => s.categories);
  const services = useDataStore((s) => s.services);

  return (
    <div className="w-full">
      <AnimatePresence mode="wait">
        {selectedCategory === null ? (
          <motion.div
            key="grid"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="grid grid-cols-2 gap-3 sm:gap-4"
          >
            {categories.map((cat, i) => (
              <motion.div
                key={cat.id}
                layoutId={`cat-${cat.id}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ ...transition, delay: i * 0.05 }}
                onClick={() => onSelectCategory(cat.id)}
                className="group relative cursor-pointer rounded-2xl bg-card border border-border p-5 sm:p-6
                           hover:border-primary/30 hover:glow-red transition-all duration-300
                           active:scale-[0.97] flex flex-col items-center text-center overflow-hidden"
              >
                {cat.bgUrl ? (
                  <img src={cat.bgUrl} alt={cat.name} className="w-12 h-12 object-cover rounded-xl mb-3" />
                ) : cat.iconUrl ? (
                  <img src={cat.iconUrl} alt={cat.name} className="w-10 h-10 object-contain mb-3" />
                ) : (
                  <span className="text-3xl sm:text-4xl block mb-3">{cat.icon}</span>
                )}
                <h3 className="font-semibold text-foreground text-sm sm:text-base">{cat.name}</h3>
                <p className="text-xs text-muted-foreground mt-1">{cat.description}</p>
                <div className="absolute inset-0 rounded-2xl bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div
            key="expanded"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              layoutId={`cat-${selectedCategory}`}
              transition={transition}
              className="rounded-2xl bg-card border border-border p-4 sm:p-5 mb-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">
                    {categories.find((c) => c.id === selectedCategory)?.icon}
                  </span>
                  <div>
                    <h3 className="font-semibold text-foreground">
                      {categories.find((c) => c.id === selectedCategory)?.name}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {categories.find((c) => c.id === selectedCategory)?.description}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onSelectCategory(null)}
                  className="text-xs text-muted-foreground hover:text-foreground transition-colors
                             px-3 py-1.5 rounded-xl bg-muted/50 hover:bg-muted"
                >
                  Voltar
                </button>
              </div>
            </motion.div>

            <div className="space-y-2">
              {services.filter((s) => s.category === selectedCategory).map((service, i) => (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06, duration: 0.3 }}
                >
                  <ServiceCard service={service} />
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CategoryGrid;
