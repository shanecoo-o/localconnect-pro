import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';
import { Service } from '@/lib/types';
import { useCartStore } from '@/stores/cart';

interface ServiceCardProps {
  service: Service;
}

export const ServiceCard = ({ service }: ServiceCardProps) => {
  const { items, addItem, removeItem } = useCartStore();
  const cartItem = items.find((i) => i.serviceId === service.id);
  const qty = cartItem?.quantity ?? 0;
  const [justAdded, setJustAdded] = useState(false);

  const handleAdd = () => {
    addItem(service.id);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 300);
  };

  return (
    <div className="flex items-center justify-between rounded-xl bg-card border border-border p-4
                    hover:border-primary/20 transition-all duration-200">
      <div className="flex-1 min-w-0">
        <p className="font-medium text-foreground text-sm">{service.name}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{service.duration} min</p>
      </div>

      <div className="flex items-center gap-3">
        <span className="text-sm font-semibold text-foreground tabular-nums">
          {service.price === 0 ? 'Grátis' : `${service.price}€`}
        </span>

        <AnimatePresence mode="wait">
          {qty === 0 ? (
            <motion.button
              key="add"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 400, damping: 20 }}
              onClick={handleAdd}
              className="flex items-center justify-center w-9 h-9 rounded-xl
                         bg-primary text-primary-foreground hover:bg-primary/90
                         active:scale-90 transition-all duration-150"
            >
              <motion.div
                animate={justAdded ? { scale: [1, 1.3, 1] } : {}}
                transition={{ duration: 0.3 }}
              >
                <Plus className="w-4 h-4" />
              </motion.div>
            </motion.button>
          ) : (
            <motion.div
              key="stepper"
              initial={{ width: 36, opacity: 0 }}
              animate={{ width: 100, opacity: 1 }}
              exit={{ width: 36, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className="flex items-center justify-between h-9 rounded-xl bg-primary overflow-hidden"
            >
              <button
                onClick={() => removeItem(service.id)}
                className="flex items-center justify-center w-9 h-full text-primary-foreground
                           hover:bg-primary-foreground/10 transition-colors"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <motion.span
                key={qty}
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-sm font-semibold text-primary-foreground tabular-nums"
              >
                {qty}
              </motion.span>
              <button
                onClick={handleAdd}
                className="flex items-center justify-center w-9 h-full text-primary-foreground
                           hover:bg-primary-foreground/10 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
