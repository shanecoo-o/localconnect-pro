import { Link, useLocation, useNavigate } from 'react-router-dom';
import { CalendarDays, LayoutDashboard, LogOut, Shield, Crown } from 'lucide-react';
import { useAuthStore } from '@/stores/auth';

const AppHeader = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);

  const handleLogout = () => { logout(); navigate('/auth'); };

  const links: { to: string; label: string; icon: typeof CalendarDays }[] = [];

  if (user) {
    if (user.role === 'super') {
      links.push({ to: '/super', label: 'Super', icon: Crown });
      links.push({ to: '/admin', label: 'Admin', icon: Shield });
      links.push({ to: '/dashboard', label: 'Painel', icon: LayoutDashboard });
    } else if (user.role === 'admin') {
      links.push({ to: '/admin', label: 'Admin', icon: Shield });
      links.push({ to: '/dashboard', label: 'Painel', icon: LayoutDashboard });
    } else if (user.role === 'barber') {
      links.push({ to: `/barber/${user.barberId || user.id}`, label: 'Agenda', icon: CalendarDays });
    } else {
      links.push({ to: '/cliente', label: 'Agendar', icon: CalendarDays });
    }
  }

  const homeLink = user
    ? user.role === 'super' ? '/super'
    : user.role === 'admin' ? '/admin'
    : user.role === 'barber' ? `/barber/${user.barberId || user.id}`
    : '/cliente'
    : '/auth';

  return (
    <header className="sticky top-0 z-20 border-b border-border glass">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          <Link to={homeLink} className="font-bold text-foreground tracking-tight text-base">
            503<span className="text-primary">BarberShop</span>
          </Link>
          <nav className="flex items-center gap-1">
            {links.map(link => {
              const isActive = location.pathname === link.to;
              return (
                <Link key={link.to} to={link.to}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-200 ${
                    isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}>
                  <link.icon className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{link.label}</span>
                </Link>
              );
            })}
            {user && (
              <button onClick={handleLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-200">
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sair</span>
              </button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default AppHeader;
