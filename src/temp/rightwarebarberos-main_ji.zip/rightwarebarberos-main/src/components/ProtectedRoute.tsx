import { Navigate } from 'react-router-dom';
import { useAuthStore, UserRole } from '@/stores/auth';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles: UserRole[];
}

const ProtectedRoute = ({ children, allowedRoles }: ProtectedRouteProps) => {
  const user = useAuthStore((s) => s.user);

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  if (!allowedRoles.includes(user.role)) {
    const redirects: Record<UserRole, string> = {
      super: '/super',
      admin: '/admin',
      barber: `/barber/${user.barberId || user.id}`,
      client: '/cliente',
    };
    return <Navigate to={redirects[user.role]} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
